"""
orchestrator.py
The Orchestrator Agent. It looks at the user's message, uses an LLM
(Llama 3.3 70B via Groq) to decide which specialized agent should
handle it, and returns that agent's response along with the agent's
name (so the UI can show "routed to: Exam Agent", etc.)

Why the LLM only picks the AGENT, and doesn't answer directly:
The actual answer (exam date, attendance %, notes) still comes from
agents.py, which reads real data out of the SQLite database. This way
the LLM can never "hallucinate" a wrong exam date -- it only makes the
routing decision, which is exactly what an Orchestrator Agent is
supposed to do.

If anything goes wrong with the LLM call (no API key set, no internet,
rate limit, etc.) we automatically fall back to simple keyword
matching, so the demo never breaks.
"""

import os
from agents import ExamAgent, AttendanceAgent, NotesAgent

# Simple keyword fallback (used if the LLM call fails for any reason)
EXAM_KEYWORDS = ["exam", "test", "schedule", "date", "notice"]
ATTENDANCE_KEYWORDS = ["attendance", "present", "absent", "percentage"]
NOTES_KEYWORDS = ["notes", "note", "summary", "summarize", "study material", "pdf"]

try:
    from langchain_groq import ChatGroq
    _GROQ_AVAILABLE = True
except ImportError:
    _GROQ_AVAILABLE = False


class Orchestrator:
    def __init__(self):
        self.exam_agent = ExamAgent()
        self.attendance_agent = AttendanceAgent()
        self.notes_agent = NotesAgent()

        self.llm = None
        api_key = os.environ.get("GROQ_API_KEY")
        if _GROQ_AVAILABLE and api_key:
            self.llm = ChatGroq(
                model="llama-3.3-70b-versatile",
                api_key=api_key,
                temperature=0,  # we want consistent, predictable routing
            )

    def _keyword_classify(self, message: str) -> str:
        """Fallback classifier: no API key / no internet needed."""
        message_lower = message.lower()
        if any(kw in message_lower for kw in ATTENDANCE_KEYWORDS):
            return "attendance"
        if any(kw in message_lower for kw in EXAM_KEYWORDS):
            return "exam"
        if any(kw in message_lower for kw in NOTES_KEYWORDS):
            return "notes"
        return "unknown"

    def _llm_classify(self, message: str) -> str:
        """Ask Llama 3.3 70B (via Groq) which agent should handle this."""
        prompt = (
            "You are the orchestrator in a college assistant app with three agents: "
            "'exam' (exam dates, schedules, notices), 'attendance' (attendance "
            "percentage, warnings), and 'notes' (subject notes, PDF summaries, study "
            "material).\n\n"
            "Read the student's message and reply with EXACTLY ONE WORD: "
            "exam, attendance, notes, or unknown. No punctuation, no explanation.\n\n"
            f"Student message: \"{message}\""
        )
        result = self.llm.invoke(prompt)
        label = result.content.strip().lower()

        # Guard against the model returning something unexpected
        for valid in ("exam", "attendance", "notes"):
            if valid in label:
                return valid
        return "unknown"

    def route(self, message: str):
        """
        Returns a tuple: (agent_name, response_text)
        """
        if self.llm is not None:
            try:
                intent = self._llm_classify(message)
            except Exception:
                # LLM call failed (network/API issue) -> fall back silently
                intent = self._keyword_classify(message)
        else:
            intent = self._keyword_classify(message)

        if intent == "exam":
            agent = self.exam_agent
        elif intent == "attendance":
            agent = self.attendance_agent
        elif intent == "notes":
            agent = self.notes_agent
        else:
            return (
                "Orchestrator",
                "I'm not sure which of my agents should handle that. "
                "Try asking about an exam date, your attendance, or subject notes."
            )

        response = agent.handle(message)
        return agent.name, response
