"""
orchestrator.py
The Orchestrator Agent. It looks at the user's message, decides which
specialized agent should handle it, and returns the agent's response
along with the name of the agent that answered (so the UI can show
"routed to: Exam Agent", etc.)

Routing is done with simple, transparent keyword rules. This is
intentional for a demo: it's fast, needs no API key, and is easy to
explain live ("here's exactly why it picked this agent"). An optional
LLM-based router (using Gemini or OpenAI) is stubbed at the bottom if
you want to upgrade it later.
"""

from agents import ExamAgent, AttendanceAgent, NotesAgent

EXAM_KEYWORDS = ["exam", "test", "schedule", "date", "notice"]
ATTENDANCE_KEYWORDS = ["attendance", "present", "absent", "percentage"]
NOTES_KEYWORDS = ["notes", "note", "summary", "summarize", "study material", "pdf"]


class Orchestrator:
    def __init__(self):
        self.exam_agent = ExamAgent()
        self.attendance_agent = AttendanceAgent()
        self.notes_agent = NotesAgent()

    def route(self, message: str):
        """
        Returns a tuple: (agent_name, response_text)
        """
        message_lower = message.lower()

        if any(kw in message_lower for kw in ATTENDANCE_KEYWORDS):
            agent = self.attendance_agent
        elif any(kw in message_lower for kw in EXAM_KEYWORDS):
            agent = self.exam_agent
        elif any(kw in message_lower for kw in NOTES_KEYWORDS):
            agent = self.notes_agent
        else:
            return (
                "Orchestrator",
                "I'm not sure which of my agents should handle that. "
                "Try asking about an exam date, your attendance, or subject notes."
            )

        response = agent.handle(message)
        return agent.name, response


# ---------------------------------------------------------------------
# OPTIONAL UPGRADE: LLM-based intent classification instead of keywords.
# Uncomment and fill in an API key if you want to demo real LLM routing.
# ---------------------------------------------------------------------
#
# import os
# from openai import OpenAI
# client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
#
# def llm_classify_intent(message: str) -> str:
#     prompt = (
#         "Classify the user's request into exactly one category: "
#         "'exam', 'attendance', or 'notes'. Reply with only the single word.\n\n"
#         f"User request: {message}"
#     )
#     resp = client.chat.completions.create(
#         model="gpt-4o-mini",
#         messages=[{"role": "user", "content": prompt}],
#     )
#     return resp.choices[0].message.content.strip().lower()
