"""
database.py
Sets up the SQLite database for CampusAI with sample data for
exams, attendance, and notes. Run this once before starting the app:

    python database.py
"""

import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "campusai.db")


def create_database():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # ---- Exams table ----
    cur.execute("DROP TABLE IF EXISTS exams")
    cur.execute("""
        CREATE TABLE exams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject TEXT NOT NULL,
            subject_code TEXT NOT NULL,
            exam_date TEXT NOT NULL,
            exam_time TEXT NOT NULL,
            notice TEXT
        )
    """)
    cur.executemany(
        "INSERT INTO exams (subject, subject_code, exam_date, exam_time, notice) VALUES (?, ?, ?, ?, ?)",
        [
            ("Database Management Systems", "DBMS", "15 July", "10:00 AM",
             "Bring your student ID card. Calculators are not allowed."),
            ("Operating Systems", "OS", "18 July", "10:00 AM",
             "Open notes exam for the last unit only."),
            ("Computer Networks", "CN", "21 July", "2:00 PM",
             "Seating arrangement will be posted on the notice board."),
            ("Data Structures and Algorithms", "DSA", "24 July", "10:00 AM", None),
        ],
    )

    # ---- Attendance table ----
    cur.execute("DROP TABLE IF EXISTS attendance")
    cur.execute("""
        CREATE TABLE attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject TEXT NOT NULL,
            subject_code TEXT NOT NULL,
            classes_held INTEGER NOT NULL,
            classes_attended INTEGER NOT NULL,
            required_percentage INTEGER NOT NULL
        )
    """)
    cur.executemany(
        "INSERT INTO attendance (subject, subject_code, classes_held, classes_attended, required_percentage) "
        "VALUES (?, ?, ?, ?, ?)",
        [
            ("Database Management Systems", "DBMS", 50, 36, 75),
            ("Operating Systems", "OS", 48, 40, 75),
            ("Computer Networks", "CN", 45, 30, 75),
            ("Overall", "OVERALL", 143, 106, 75),
        ],
    )

    # ---- Notes table ----
    cur.execute("DROP TABLE IF EXISTS notes")
    cur.execute("""
        CREATE TABLE notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject TEXT NOT NULL,
            subject_code TEXT NOT NULL,
            file_name TEXT NOT NULL,
            summary TEXT NOT NULL
        )
    """)
    cur.executemany(
        "INSERT INTO notes (subject, subject_code, file_name, summary) VALUES (?, ?, ?, ?)",
        [
            ("Operating Systems", "OS", "OS_Unit4_Deadlocks.pdf",
             "Covers deadlock conditions, prevention, avoidance (Banker's Algorithm), "
             "detection, and recovery strategies."),
            ("Database Management Systems", "DBMS", "DBMS_Unit3_Normalization.pdf",
             "Covers 1NF, 2NF, 3NF, BCNF with examples, and functional dependency basics."),
            ("Computer Networks", "CN", "CN_Unit2_Routing.pdf",
             "Covers distance vector and link state routing algorithms, with a comparison "
             "of RIP and OSPF."),
        ],
    )

    conn.commit()
    conn.close()
    print(f"Database created at: {DB_PATH}")


if __name__ == "__main__":
    create_database()
