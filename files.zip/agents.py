"""
agents.py
Defines the three specialized agents used by CampusAI.
Each agent is responsible for one domain and knows how to query
the SQLite database for the information it owns.
"""

import sqlite3
from database import DB_PATH


def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


class ExamAgent:
    """Handles exam dates, schedules, and exam-related notices."""

    name = "Exam Agent"

    def handle(self, message: str) -> str:
        conn = _connect()
        cur = conn.cursor()
        cur.execute("SELECT * FROM exams")
        exams = cur.fetchall()
        conn.close()

        message_lower = message.lower()
        matched = None
        for exam in exams:
            if exam["subject_code"].lower() in message_lower or exam["subject"].lower() in message_lower:
                matched = exam
                break

        if matched:
            response = f"Your {matched['subject_code']} exam is on {matched['exam_date']} at {matched['exam_time']}."
            if matched["notice"]:
                response += f" Note: {matched['notice']}"
            return response

        # No specific subject found -> show full schedule
        lines = ["Here is your exam schedule:"]
        for exam in exams:
            lines.append(f"- {exam['subject_code']} ({exam['subject']}): {exam['exam_date']} at {exam['exam_time']}")
        return "\n".join(lines)


class AttendanceAgent:
    """Handles attendance percentage checks and warnings."""

    name = "Attendance Agent"

    def handle(self, message: str) -> str:
        conn = _connect()
        cur = conn.cursor()
        cur.execute("SELECT * FROM attendance")
        records = cur.fetchall()
        conn.close()

        message_lower = message.lower()
        matched = None
        for rec in records:
            if rec["subject_code"].lower() != "overall" and (
                rec["subject_code"].lower() in message_lower or rec["subject"].lower() in message_lower
            ):
                matched = rec
                break

        if matched is None:
            # Default to overall attendance
            matched = next(r for r in records if r["subject_code"].lower() == "overall")
            label = "overall"
        else:
            label = matched["subject_code"]

        percentage = round((matched["classes_attended"] / matched["classes_held"]) * 100, 1)
        required = matched["required_percentage"]

        response = f"Your {label} attendance is {percentage}%."

        if percentage < required:
            # Classes needed to reach required % without missing any more:
            # (attended + x) / (held + x) >= required/100  =>  solve for x
            attended = matched["classes_attended"]
            held = matched["classes_held"]
            req = required / 100
            import math
            x = math.ceil((req * held - attended) / (1 - req)) if req < 1 else 0
            x = max(x, 0)
            response += f" You need {x} more consecutive classes to reach {required}%."
        else:
            response += f" You are above the required {required}% — keep it up!"

        return response


class NotesAgent:
    """Handles subject notes, PDF summaries, and study material suggestions."""

    name = "Notes Agent"

    def handle(self, message: str) -> str:
        conn = _connect()
        cur = conn.cursor()
        cur.execute("SELECT * FROM notes")
        all_notes = cur.fetchall()
        conn.close()

        message_lower = message.lower()
        matched = None
        for note in all_notes:
            if note["subject_code"].lower() in message_lower or note["subject"].lower() in message_lower:
                matched = note
                break

        if matched:
            return (
                f"Here are your {matched['subject_code']} notes: {matched['file_name']}\n"
                f"Summary: {matched['summary']}"
            )

        lines = ["I couldn't find that exact subject, but here's what I have notes for:"]
        for note in all_notes:
            lines.append(f"- {note['subject_code']} ({note['subject']}): {note['file_name']}")
        return "\n".join(lines)
