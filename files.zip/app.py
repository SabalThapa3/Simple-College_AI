"""
app.py
Streamlit front-end for CampusAI.

Run with:
    streamlit run app.py
"""

import streamlit as st
from dotenv import load_dotenv
from orchestrator import Orchestrator

load_dotenv()  # reads GROQ_API_KEY from a local .env file, if present

st.set_page_config(page_title="CampusAI", page_icon="🎓", layout="centered")

# ---- Session state ----
if "orchestrator" not in st.session_state:
    st.session_state.orchestrator = Orchestrator()

if "messages" not in st.session_state:
    st.session_state.messages = [
        {
            "role": "assistant",
            "agent": "CampusAI",
            "content": (
                "Hi! I'm CampusAI 🎓 — ask me about your **exams**, "
                "**attendance**, or **notes**.\n\n"
                "Try one of these:\n"
                "- \"When is my DBMS exam?\"\n"
                "- \"Check my attendance.\"\n"
                "- \"Give me OS notes.\""
            ),
        }
    ]

AGENT_BADGES = {
    "Exam Agent": "📅 Exam Agent",
    "Attendance Agent": "📊 Attendance Agent",
    "Notes Agent": "📚 Notes Agent",
    "Orchestrator": "🤖 Orchestrator",
    "CampusAI": "🎓 CampusAI",
}

st.title("🎓 CampusAI")
st.caption("An Agentic AI College Assistant — routes your question to the right specialist agent.")

with st.sidebar:
    if st.session_state.orchestrator.llm is not None:
        st.success("🧠 LLM routing active (Llama 3.3 70B via Groq)")
    else:
        st.warning("⚠️ No GROQ_API_KEY found — using keyword-based routing fallback")

    st.header("How it works")
    st.markdown(
        "**Orchestrator Agent** reads your message and routes it to one of:\n\n"
        "- 📅 **Exam Agent** — exam dates & schedules\n"
        "- 📊 **Attendance Agent** — attendance % & warnings\n"
        "- 📚 **Notes Agent** — subject notes & summaries\n"
    )
    st.divider()
    st.subheader("Quick demo prompts")
    demo_prompts = [
        "When is my DBMS exam?",
        "Check my attendance.",
        "Give me OS notes.",
    ]
    for p in demo_prompts:
        if st.button(p, use_container_width=True):
            st.session_state["pending_prompt"] = p

# ---- Render chat history ----
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        if msg["role"] == "assistant":
            st.markdown(f"**{AGENT_BADGES.get(msg['agent'], msg['agent'])}**")
        st.markdown(msg["content"])

# ---- Handle input (typed or from sidebar demo button) ----
prompt = st.chat_input("Ask about exams, attendance, or notes...")
if not prompt and "pending_prompt" in st.session_state:
    prompt = st.session_state.pop("pending_prompt")

if prompt:
    st.session_state.messages.append({"role": "user", "agent": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    agent_name, response = st.session_state.orchestrator.route(prompt)

    st.session_state.messages.append({"role": "assistant", "agent": agent_name, "content": response})
    with st.chat_message("assistant"):
        st.markdown(f"**{AGENT_BADGES.get(agent_name, agent_name)}**")
        st.markdown(response)
