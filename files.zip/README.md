# CampusAI — Agentic AI College Assistant (Demo Prototype)

A working prototype for your 3-hour demo. An **Orchestrator Agent** uses
**Llama 3.3 70B (via Groq)** to read the student's message and decide which
of three specialized agents should answer: **Exam**, **Attendance**, or
**Notes**. Each agent then pulls its actual answer from a SQLite database
(so the LLM decides *who* answers, but never invents the data itself).

## Project structure

```
campusai/
├── app.py            # Streamlit chat UI (the demo front-end)
├── orchestrator.py    # Uses Groq/Llama to route messages to the right agent
├── agents.py          # ExamAgent, AttendanceAgent, NotesAgent
├── database.py        # Creates campusai.db with sample data
├── requirements.txt
└── .env.example        # Template for your Groq API key
```

## Setup (10 minutes, beginner-friendly)

### 1. Get a free Groq API key
- Go to https://console.groq.com
- Sign up (free) and create an API key.

### 2. Install everything
```bash
cd campusai
pip install -r requirements.txt
```

### 3. Add your API key
Copy `.env.example` to `.env` and paste your key in:

```bash
cp .env.example .env
```

Then edit `.env` so it looks like:
```
GROQ_API_KEY=gsk_your_actual_key_here
```

### 4. Create the database
```bash
python database.py
```

### 5. Run the app
```bash
streamlit run app.py
```

Your browser will open automatically. The sidebar shows a green
"LLM routing active" message once your key is working.

**If you don't set up a Groq key**, the app still works — it automatically
falls back to simple keyword-based routing, so you're never stuck without
a working demo (e.g. if there's no wifi during your presentation).

## Demo script (matches your 3 hardcoded prompts)

Type these into the chat box, or just click them in the sidebar:

1. **"When is my DBMS exam?"** → routed to **Exam Agent**
   → "Your DBMS exam is on 15 July at 10:00 AM. Note: Bring your student ID card..."

2. **"Check my attendance."** → routed to **Attendance Agent**
   → "Your overall attendance is 74.1%. You need 5 more consecutive classes to reach 75%."

3. **"Give me OS notes."** → routed to **Notes Agent**
   → "Here are your OS notes: OS_Unit4_Deadlocks.pdf. Summary: Covers deadlock conditions..."

Each response in the UI is labeled with which agent answered (📅 Exam Agent,
📊 Attendance Agent, 📚 Notes Agent) — so it's visually obvious that
different requests are being handled by different agents.

## How routing works (the important part to explain in your demo)

`orchestrator.py` sends the student's message to Llama 3.3 70B with a
short prompt asking it to reply with exactly one word: `exam`,
`attendance`, `notes`, or `unknown`. That word decides which agent
handles the request:

```python
result = self.llm.invoke(prompt)
label = result.content.strip().lower()
```

The agent itself (`agents.py`) never touches the LLM — it just looks up
real rows in the SQLite database. This split (LLM decides *routing*,
database provides *facts*) is what makes the answers reliable even
though the routing is "AI-powered."

If the Groq call fails for any reason (no key, no internet, rate limit),
`orchestrator.py` catches the error and falls back to simple keyword
matching automatically — nothing crashes mid-demo.

## Extending beyond the demo

- Swap the hardcoded sample data in `database.py` for a real student
  records system.
- Add a real PDF summarizer to `NotesAgent` (e.g. PyPDF2 + a Groq call)
  for actual uploaded files instead of pre-written summaries.
- Add authentication so `attendance`/`exams` are filtered by logged-in
  student ID rather than showing one shared dataset.
- Let the LLM also generate a friendlier final sentence around the raw
  database facts, instead of just picking the agent (still keep the
  facts themselves coming from the database, not the LLM).
