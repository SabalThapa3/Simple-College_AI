# CampusAI — Agentic AI College Assistant (Demo Prototype)

A working prototype for your 3-hour demo. It shows a real agentic workflow:
an **Orchestrator Agent** reads the student's message and routes it to one
of three specialized agents (**Exam**, **Attendance**, **Notes**), each of
which pulls its answer from a SQLite database.

## Project structure

```
campusai/
├── app.py            # Streamlit chat UI (the demo front-end)
├── orchestrator.py   # Routes messages to the right agent
├── agents.py         # ExamAgent, AttendanceAgent, NotesAgent
├── database.py       # Creates campusai.db with sample data
└── requirements.txt
```

## Setup (5 minutes)

```bash
cd campusai
pip install -r requirements.txt
python database.py      # creates campusai.db with sample exam/attendance/notes data
streamlit run app.py    # launches the demo UI in your browser
```

## Demo script (matches your 3 hardcoded prompts)

Type these into the chat box, or just click them in the sidebar:

1. **"When is my DBMS exam?"** → routed to **Exam Agent**
   → "Your DBMS exam is on 15 July at 10:00 AM. Note: Bring your student ID card..."

2. **"Check my attendance."** → routed to **Attendance Agent**
   → "Your overall attendance is 74.1%. You need 5 more consecutive classes to reach 75%."

3. **"Give me OS notes."** → routed to **Notes Agent**
   → "Here are your OS notes: OS_Unit4_Deadlocks.pdf. Summary: Covers deadlock conditions..."

Each response in the UI is labeled with which agent answered (📅 Exam Agent,
📊 Attendance Agent, 📚 Notes Agent), so it's visually obvious to anyone
watching the demo that different requests are being handled by different
agents — this is the core thing you want to show off.

## How routing works

`orchestrator.py` uses simple, transparent keyword matching:

- Attendance keywords (`attendance`, `present`, `absent`, `percentage`) → Attendance Agent
- Exam keywords (`exam`, `test`, `schedule`, `date`, `notice`) → Exam Agent
- Notes keywords (`notes`, `summary`, `summarize`, `pdf`) → Notes Agent

This is intentional for a live demo: it's instant, needs no API key, and you
can explain exactly why a message was routed where it was if someone asks.

### Optional upgrade: real LLM-based routing

If you want to show off actual LLM intent classification instead of
keywords, `orchestrator.py` has a commented-out `llm_classify_intent()`
function at the bottom using the OpenAI API. To use it (or swap in Gemini),
you'd:

1. Get an API key (OpenAI or Google AI Studio for Gemini).
2. `pip install openai` (or `google-generativeai`).
3. Uncomment that section and replace the keyword `if/elif` chain in
   `Orchestrator.route()` with a call to `llm_classify_intent(message)`.

This is a nice "if I had more time" talking point even if you don't wire it
up for the 3-hour demo — keyword routing is more reliable live anyway
(no network dependency, no API latency, no risk of a wrong classification
mid-demo).

## Extending beyond the demo

- Swap the hardcoded sample data in `database.py` for a real student
  records system.
- Add a real PDF summarizer to `NotesAgent` (e.g. PyPDF2 + an LLM call) for
  actual uploaded files instead of pre-written summaries.
- Add authentication so `attendance`/`exams` are filtered by logged-in
  student ID rather than showing one shared dataset.
- Replace keyword routing with the LLM classifier above, or a proper
  framework like LangGraph/CrewAI, once you want multi-step agent
  reasoning (e.g. an agent that checks attendance *and* pulls notes in
  one request).
